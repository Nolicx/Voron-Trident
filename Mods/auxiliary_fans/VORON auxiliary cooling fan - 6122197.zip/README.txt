VORON auxiliary cooling fan by FYSETC_Ltd on Thingiverse: https://www.thingiverse.com/thing:6122197

Summary:
The kit is mainly used to increase the cooling effect of the product when the VORON machine prints, with 24V 12032 large blower as an auxiliary cooling fan, which can provide strong wind power, greatly increasing its cooling effect, providing more favourable support for the printer to print complex models, and lowering the threshold of its printer to print the model; to achieve that their printers out of the material that is cold, and moulding that is stable.